console.log('Message from assets/js/custom.js');
